Welcome to Blind Gallery CTF.

Objective: Find the final flag hidden in the blind spots of this gallery.

Some things are not what they seem.
