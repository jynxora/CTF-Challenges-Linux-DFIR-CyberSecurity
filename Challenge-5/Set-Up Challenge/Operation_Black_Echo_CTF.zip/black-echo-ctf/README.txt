Operation Black Echo CTF Instructions:
Investigate artifacts for hidden flags.
Good luck.
