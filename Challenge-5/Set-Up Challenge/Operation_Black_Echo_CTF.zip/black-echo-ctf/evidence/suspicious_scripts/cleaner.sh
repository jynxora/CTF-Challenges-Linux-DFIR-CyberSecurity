#!/bin/bash
rm -rf /tmp/malware
